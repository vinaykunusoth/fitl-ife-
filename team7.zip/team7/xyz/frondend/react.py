import streamlit as st
import pandas as pd
import time

st.title("Disease Exercise Recommendations 🏋️‍♂️")

# Upload Excel file
uploaded_file = st.file_uploader("Upload an Excel file", type=["xlsx"])

if uploaded_file:
    # Read Excel file
    df = pd.read_excel(uploaded_file)
    diseases = df['Disease'].unique()

    # Select Disease
    selected_disease = st.selectbox("Select a Disease 🦠", diseases)

    # Filter exercises for selected disease
    filtered_exercises = df[df['Disease'] == selected_disease]

    st.header(f"Exercises for {selected_disease} 💪")
    
    for idx, row in filtered_exercises.iterrows():
        exercise_name = row['Exercise']
        emoji = row['Emoji']
        st.write(f"{exercise_name} {emoji}")

        # Timer button
        if st.button(f"Start 1-min Timer for {exercise_name} ⏱️", key=idx):
            with st.empty():
                for sec in range(60, 0, -1):
                    st.metric(label=f"⏳ {exercise_name}", value=f"{sec} seconds remaining")
                    time.sleep(1)
                st.success(f"Completed {exercise_name}! 🎉")
