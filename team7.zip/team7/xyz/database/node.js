const express = require("express");
const admin = require("firebase-admin");
const bodyParser = require("body-parser");

const serviceAccount = require("./path/to/serviceAccountKey.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://fitness-database-969b5-default-rtdb.firebaseio.com"
});

const db = admin.database();
const app = express();
app.use(bodyParser.json());

// API to Get All Users
app.get("/users", async (req, res) => {
  const ref = db.ref("users");
  ref.once("value", (snapshot) => {
    res.json(snapshot.val());
  });
});

// API to Add New User
app.post("/add-user", (req, res) => {
  const ref = db.ref("users");
  ref.push(req.body)
    .then(() => res.send("User added successfully"))
    .catch((error) => res.status(500).send(error));
});

app.listen(3000, () => console.log("Server running on port 3000"));

