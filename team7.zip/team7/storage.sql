CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    date_of_birth DATE NOT NULL,
    fitness_goal ENUM('Muscle Gain', 'Weight Loss', 'Endurance', 'General Fitness') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);