import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score, classification_report

# Load dataset
data = pd.read_csv('diease.csv')

# Data Cleaning
data.dropna(inplace=True)

# Encode categorical variables
label_encoder = LabelEncoder()
data['diease'] = label_encoder.fit_transform(data['diease'])

# Feature and target selection
X = data.drop(['dieases'], axis=1)
y = data['dieases']

# Feature Scaling
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# Model Training
model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)

# Model Evaluation
y_pred = model.predict(X_test)
print("Accuracy:", accuracy_score(y_test, y_pred))
print("Classification Report:\n", classification_report(y_test, y_pred))

# Disease to Exercise Mapping
disease_exercises = {
    'Diabetes': ['Walking', 'Cycling', 'Yoga'],
    'Hypertension': ['Swimming', 'Tai Chi', 'Brisk Walking'],
    'Obesity': ['Running', 'Strength Training', 'Aerobics'],
    'Asthma': ['Swimming', 'Walking', 'Breathing Exercises']
}

# User Interface for Predictions
user_input = [float(input(f"Enter {col}: ")) for col in X.columns]
user_input_scaled = scaler.transform([user_input])
predicted_disease_encoded = model.predict(user_input_scaled)[0]
predicted_disease = label_encoder.inverse_transform([predicted_disease_encoded])[0]

# Recommend Exercises
recommended_exercises = disease_exercises.get(predicted_disease, ["No specific exercises available"])

print(f"\nPredicted Disease: {predicted_disease}")
print("Recommended Exercises:", ', '.join(recommended_exercises))